package ma.projet.arrosageintellegentv2.beans;

public class Notification {
    private long id;

    public Notification() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
}
